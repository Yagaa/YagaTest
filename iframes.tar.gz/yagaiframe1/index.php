<html>
    <head></head>
    <body>
        <iframe src="http://yagaiframe2.com" id="iframe"></iframe>
        <form id="form">
          <input type="text" id="msg" value="Message to send"/>
          <input type="submit"/>
        </form>
        <script>
        window.onload = function(){
                var win = document.getElementById("iframe").contentWindow;
                document.getElementById("form").onsubmit = function(e){
                        win.postMessage(
                                document.getElementById("msg").value,
                                "http://yagaiframe2.com"
                        );
                        e.preventDefault();
                };
        };
        </script>
    </body>
</html>