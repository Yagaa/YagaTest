<html>
    <head></head>
    <body>
        <div id="test">
            Send me a message!
        </div>
        <script>
            function ListenEvent(e){
                if (e.origin !== "http://yagaiframe1.com")
                    return;

                document.getElementById("test").textContent = e.origin + " said: " + e.data;
            }
            window.addEventListener("message",ListenEvent, false);
        </script>
    </body>
</html>